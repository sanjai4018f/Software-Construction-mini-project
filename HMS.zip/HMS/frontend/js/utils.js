// ============================================
// City Care HMS - Global JS Utilities
// ============================================

const API_BASE = 'http://localhost:8080/api';

// ---- API Helper ----
async function apiCall(method, endpoint, data = null) {
  const opts = {
    method,
    headers: { 'Content-Type': 'application/json' }
  };
  if (data) opts.body = JSON.stringify(data);
  try {
    const res = await fetch(API_BASE + endpoint, opts);
    let json = null;
    try {
      json = await res.json();
    } catch (e) {
      // Response is not JSON
      json = { message: res.statusText || 'Server Error' };
    }
    
    // Log response for debugging in console
    console.log(`[${method} ${endpoint}] Status: ${res.status}`, json);
    
    return { ok: res.ok, status: res.status, data: json };
  } catch (err) {
    console.error(`[${method} ${endpoint}] Network Error:`, err);
    return { 
      ok: false, 
      status: 0, 
      data: { message: 'Cannot connect to server. Is the backend running at ' + API_BASE + '?' } 
    };
  }
}

// ---- Session ----
function setSession(role, data) {
  sessionStorage.setItem('hms_role', role);
  sessionStorage.setItem('hms_user', JSON.stringify(data));
}

function getSession() {
  const role = sessionStorage.getItem('hms_role');
  const user = JSON.parse(sessionStorage.getItem('hms_user') || 'null');
  return { role, user };
}

function clearSession() {
  sessionStorage.removeItem('hms_role');
  sessionStorage.removeItem('hms_user');
}

function requireAuth(expectedRole) {
  const { role, user } = getSession();
  if (!role || !user) { window.location.href = '../index.html'; return null; }
  if (expectedRole && role !== expectedRole) { window.location.href = '../index.html'; return null; }
  return user;
}

// ---- Alerts ----
function showAlert(container, message, type = 'success') {
  const icons = { success: '✔', error: '✖', info: 'ℹ' };
  const el = document.getElementById(container) || document.querySelector('.' + container);
  if (!el) return;
  el.innerHTML = `<div class="alert alert-${type}">${icons[type] || ''} ${message}</div>`;
  setTimeout(() => { if (el.innerHTML) el.innerHTML = ''; }, 4000);
}

// ---- Loading Button ----
function setLoading(btn, loading) {
  if (loading) {
    btn.dataset.original = btn.innerHTML;
    btn.innerHTML = '⏳ Please wait...';
    btn.disabled = true;
  } else {
    btn.innerHTML = btn.dataset.original || btn.innerHTML;
    btn.disabled = false;
  }
}

// ---- Date Formatting ----
function formatDate(dateStr) {
  if (!dateStr) return '-';
  const d = new Date(dateStr);
  return d.toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' });
}

// ---- Status Badge HTML ----
function statusBadge(status) {
  const map = {
    PENDING: 'badge-pending',
    APPROVED: 'badge-approved',
    REJECTED: 'badge-rejected'
  };
  const icons = { PENDING: '⏳', APPROVED: '✅', REJECTED: '❌' };
  return `<span class="badge ${map[status] || ''}">${icons[status] || ''} ${status}</span>`;
}

// ---- Logout ----
function logout() {
  clearSession();
  window.location.href = '../../index.html';
}

// ---- Render Sidebar User ----
function renderSidebarUser(user, role) {
  const nameEl = document.getElementById('sidebar-user-name');
  const roleEl = document.getElementById('sidebar-user-role');
  const avatarEl = document.getElementById('sidebar-avatar');
  if (nameEl) nameEl.textContent = user.name || user.username || 'User';
  if (roleEl) roleEl.textContent = role;
  if (avatarEl) avatarEl.textContent = (user.name || user.username || 'U')[0].toUpperCase();
}

// ---- Active Nav ----
function setActiveNav() {
  const currentPage = window.location.pathname.split('/').pop();
  document.querySelectorAll('.sidebar-nav a').forEach(link => {
    if (link.getAttribute('href') === currentPage) link.classList.add('active');
  });
}

document.addEventListener('DOMContentLoaded', setActiveNav);
