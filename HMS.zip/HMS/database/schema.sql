-- ============================================
-- Hospital Management System - Database Schema
-- ============================================

CREATE DATABASE IF NOT EXISTS hms_db;
USE hms_db;

-- Doctors table
CREATE TABLE IF NOT EXISTS doctors (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    specialization VARCHAR(100) NOT NULL,
    phone VARCHAR(15),
    experience INT DEFAULT 0,
    qualification VARCHAR(100),
    available_days VARCHAR(100) DEFAULT 'Mon-Fri',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Patients table
CREATE TABLE IF NOT EXISTS patients (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    age INT,
    phone VARCHAR(15),
    address TEXT,
    blood_group VARCHAR(5),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Appointments table
CREATE TABLE IF NOT EXISTS appointments (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    patient_id BIGINT NOT NULL,
    doctor_id BIGINT NOT NULL,
    appointment_date DATE NOT NULL,
    appointment_time VARCHAR(10),
    reason TEXT,
    status ENUM('PENDING', 'APPROVED', 'REJECTED') DEFAULT 'PENDING',
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (patient_id) REFERENCES patients(id) ON DELETE CASCADE,
    FOREIGN KEY (doctor_id) REFERENCES doctors(id) ON DELETE CASCADE
);

-- Admin table
CREATE TABLE IF NOT EXISTS admins (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    email VARCHAR(100)
);

-- ============================================
-- Seed Data
-- ============================================

INSERT INTO admins (username, password, email) VALUES 
('admin', 'admin123', 'admin@citycare.com');

INSERT INTO doctors (name, email, password, specialization, phone, experience, qualification, available_days) VALUES
('Dr. Arjun Mehta', 'arjun@citycare.com', 'doctor123', 'Cardiologist', '9876543210', 12, 'MD, DM Cardiology', 'Mon-Sat'),
('Dr. Priya Sharma', 'priya@citycare.com', 'doctor123', 'Neurologist', '9876543211', 8, 'MD, DM Neurology', 'Mon-Fri'),
('Dr. Ravi Kumar', 'ravi@citycare.com', 'doctor123', 'Orthopedist', '9876543212', 15, 'MS Orthopaedics', 'Tue-Sun'),
('Dr. Sneha Patel', 'sneha@citycare.com', 'doctor123', 'Pediatrician', '9876543213', 10, 'MD Pediatrics', 'Mon-Sat'),
('Dr. Vikram Singh', 'vikram@citycare.com', 'doctor123', 'Dermatologist', '9876543214', 7, 'MD Dermatology', 'Mon-Fri');
