# 🏥 City Care Hospital Management System

A full-stack Hospital Management System built with **HTML/CSS/JS** (frontend) and **Java Spring Boot + MySQL** (backend).

---

## 📁 Project Structure

```
HMS/
├── index.html                          ← Homepage (open this in browser)
├── frontend/
│   ├── css/
│   │   └── style.css                  ← Global stylesheet
│   ├── js/
│   │   └── utils.js                   ← API helpers & utilities
│   └── pages/
│       ├── patient-login.html         ← Patient login
│       ├── patient-register.html      ← Patient registration
│       ├── patient-dashboard.html     ← Book appointments
│       ├── patient-appointments.html  ← View appointment history
│       ├── doctor-login.html          ← Doctor login
│       ├── doctor-dashboard.html      ← Manage appointments
│       ├── admin-login.html           ← Admin login
│       └── admin-dashboard.html       ← Full admin panel
├── backend/
│   ├── pom.xml                        ← Maven config
│   └── src/main/
│       ├── java/com/hms/
│       │   ├── HospitalManagementApplication.java
│       │   ├── config/CorsConfig.java
│       │   ├── model/
│       │   │   ├── Doctor.java
│       │   │   ├── Patient.java
│       │   │   ├── Appointment.java
│       │   │   └── Admin.java
│       │   ├── repository/
│       │   │   ├── DoctorRepository.java
│       │   │   ├── PatientRepository.java
│       │   │   ├── AppointmentRepository.java
│       │   │   └── AdminRepository.java
│       │   └── controller/
│       │       ├── PatientController.java
│       │       ├── DoctorController.java
│       │       ├── AppointmentController.java
│       │       └── AdminController.java
│       └── resources/
│           └── application.properties
└── database/
    └── schema.sql                     ← DB setup script
```

---

## ⚙️ Setup Instructions

### Step 1: MySQL Database Setup

1. Open **MySQL Workbench** or any MySQL client
2. Run the SQL script:
   ```
   database/schema.sql
   ```
3. This creates the `hms_db` database with all tables and sample data

---

### Step 2: Backend Setup (Spring Boot)

1. Open **VS Code** (or IntelliJ IDEA)
2. Install extensions: **Extension Pack for Java**, **Spring Boot Extension Pack**
3. Open the `backend/` folder in VS Code

4. Update database credentials in `backend/src/main/resources/application.properties`:
   ```properties
   spring.datasource.username=root
   spring.datasource.password=YOUR_MYSQL_PASSWORD
   ```

5. Run the application:
   - In VS Code: Click **Run** on `HospitalManagementApplication.java`
   - Or via terminal:
     ```bash
     cd backend
     mvn spring-boot:run
     ```

6. Backend will start at: `http://localhost:8080`

---

### Step 3: Frontend Setup

1. Open the `HMS/` root folder in VS Code
2. Install the **Live Server** extension
3. Right-click on `index.html` → **Open with Live Server**
4. The website opens at `http://127.0.0.1:5500`

> ⚠️ Make sure the backend is running BEFORE opening the frontend!

---

## 🔑 Login Credentials

| Role    | Field    | Value              |
|---------|----------|--------------------|
| Admin   | Username | `admin`            |
| Admin   | Password | `admin123`         |
| Doctor  | Email    | `arjun@citycare.com` |
| Doctor  | Password | `doctor123`        |
| Doctor  | Email    | `priya@citycare.com` |
| Doctor  | Password | `doctor123`        |

> **Patients** need to register first via the Patient Portal.

---

## 🌐 API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/patient/register` | Register patient |
| POST | `/api/patient/login` | Patient login |
| POST | `/api/doctor/login` | Doctor login |
| GET | `/api/doctor/all` | List all doctors |
| POST | `/api/appointment/book` | Book appointment |
| GET | `/api/appointment/patient/{id}` | Patient's appointments |
| GET | `/api/appointment/doctor/{id}` | Doctor's appointments |
| PUT | `/api/appointment/{id}/status` | Approve/Reject |
| POST | `/api/admin/login` | Admin login |
| GET | `/api/admin/dashboard` | Dashboard stats |
| POST | `/api/admin/doctor/add` | Add doctor |
| DELETE | `/api/admin/doctor/{id}` | Remove doctor |
| GET | `/api/admin/patients` | All patients |
| GET | `/api/appointment/all` | All appointments |

---

## 🏗️ Tech Stack

| Layer | Technology |
|-------|-----------|
| Frontend | HTML5, CSS3, Vanilla JavaScript |
| Backend | Java 17, Spring Boot 3.2 |
| Database | MySQL 8.0 |
| ORM | Spring Data JPA / Hibernate |
| Build Tool | Maven |

---

## 🚀 Features

### Patient Module
- ✅ Registration with name, age, phone, email, address, blood group, password
- ✅ Login with email & password
- ✅ Book appointments by selecting doctor, date & time slot
- ✅ View appointment history with status (Pending / Approved / Rejected)
- ✅ View doctor's notes on appointments

### Doctor Module
- ✅ Login only (admin-created accounts)
- ✅ View all patient appointments
- ✅ Approve or Reject each appointment
- ✅ Add notes when approving/rejecting
- ✅ Search & filter appointments

### Admin Module
- ✅ Dashboard with total doctors, patients, appointments
- ✅ Pending / Approved / Rejected counts
- ✅ Doctor performance stats (patients handled, appointment count)
- ✅ Add new doctors
- ✅ Remove doctors
- ✅ View all registered patients
- ✅ Complete appointments table

---

## 🔧 Troubleshooting

**Backend won't start?**
- Check MySQL is running on port 3306
- Verify username/password in `application.properties`
- Make sure Java 17+ is installed: `java -version`
- Run database schema first

**Frontend shows "Server error"?**
- Make sure backend is running at `http://localhost:8080`
- Check browser console for CORS errors
- Use Live Server (not file://) to open the frontend

**Maven errors?**
- Run `mvn clean install` to download dependencies
- Ensure you have internet connection for first run

---

## 👨‍💻 Development

Developed with ❤️ for City Care Hospital
Version: 1.0.0 | Java 17 | Spring Boot 3.2 | MySQL 8
