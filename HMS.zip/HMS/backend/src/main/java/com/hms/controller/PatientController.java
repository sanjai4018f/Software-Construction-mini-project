package com.hms.controller;

import com.hms.model.Patient;
import com.hms.repository.PatientRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

@RestController
@RequestMapping("/api/patient")
public class PatientController {

    private static final String RESPONSE_SUCCESS = "success";
    private static final String RESPONSE_MESSAGE = "message";
    
    private final PatientRepository patientRepository;

    public PatientController(PatientRepository patientRepository) {
        this.patientRepository = patientRepository;
    }

    // Register patient
    @PostMapping("/register")
    public ResponseEntity<Map<String, Object>> register(@RequestBody Patient patient) {
        Map<String, Object> response = new HashMap<>();
        if (patientRepository.existsByEmail(patient.getEmail())) {
            response.put(RESPONSE_SUCCESS, false);
            response.put(RESPONSE_MESSAGE, "Email already registered");
            return ResponseEntity.badRequest().body(response);
        }
        Patient saved = patientRepository.save(patient);
        saved.setPassword(null); // don't return password
        response.put(RESPONSE_SUCCESS, true);
        response.put(RESPONSE_MESSAGE, "Registration successful");
        response.put("patient", saved);
        return ResponseEntity.ok(response);
    }

    // Login patient
    @PostMapping("/login")
    public ResponseEntity<Map<String, Object>> login(@RequestBody Map<String, String> credentials) {
        Map<String, Object> response = new HashMap<>();
        String email = credentials.get("email");
        String password = credentials.get("password");

        Optional<Patient> patientOpt = patientRepository.findByEmail(email);
        if (patientOpt.isEmpty() || !patientOpt.get().getPassword().equals(password)) {
            response.put(RESPONSE_SUCCESS, false);
            response.put(RESPONSE_MESSAGE, "Invalid email or password");
            return ResponseEntity.badRequest().body(response);
        }

        Patient patient = patientOpt.get();
        patient.setPassword(null);
        response.put(RESPONSE_SUCCESS, true);
        response.put(RESPONSE_MESSAGE, "Login successful");
        response.put("patient", patient);
        return ResponseEntity.ok(response);
    }

    // Get patient by ID
    @GetMapping("/{id}")
    public ResponseEntity<Patient> getPatient(@PathVariable Long id) {
        return patientRepository.findById(id)
                .map(p -> { p.setPassword(null); return ResponseEntity.ok(p); })
                .orElse(ResponseEntity.notFound().build());
    }
}
