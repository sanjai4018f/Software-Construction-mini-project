package com.hms.controller;

import com.hms.model.*;
import com.hms.repository.*;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.*;

@RestController
@RequestMapping("/api/admin")
public class AdminController {

    private static final String RESPONSE_SUCCESS = "success";
    private static final String RESPONSE_MESSAGE = "message";

    private final AdminRepository adminRepository;
    private final DoctorRepository doctorRepository;
    private final PatientRepository patientRepository;
    private final AppointmentRepository appointmentRepository;

    public AdminController(AdminRepository adminRepository,
                          DoctorRepository doctorRepository,
                          PatientRepository patientRepository,
                          AppointmentRepository appointmentRepository) {
        this.adminRepository = adminRepository;
        this.doctorRepository = doctorRepository;
        this.patientRepository = patientRepository;
        this.appointmentRepository = appointmentRepository;
    }

    // Admin login
    @PostMapping("/login")
    public ResponseEntity<Map<String, Object>> login(@RequestBody Map<String, String> credentials) {
        Map<String, Object> response = new HashMap<>();
        String username = credentials.get("username");
        String password = credentials.get("password");

        Optional<Admin> adminOpt = adminRepository.findByUsername(username);
        if (adminOpt.isEmpty() || !adminOpt.get().getPassword().equals(password)) {
            response.put(RESPONSE_SUCCESS, false);
            response.put(RESPONSE_MESSAGE, "Invalid credentials");
            return ResponseEntity.badRequest().body(response);
        }

        response.put(RESPONSE_SUCCESS, true);
        response.put(RESPONSE_MESSAGE, "Login successful");
        response.put("admin", adminOpt.get());
        return ResponseEntity.ok(response);
    }

    // Dashboard statistics
    @GetMapping("/dashboard")
    public ResponseEntity<Map<String, Object>> getDashboard() {
        Map<String, Object> dashboard = new HashMap<>();

        long totalDoctors = doctorRepository.count();
        long totalPatients = patientRepository.count();
        long totalAppointments = appointmentRepository.count();

        List<Doctor> doctors = doctorRepository.findAll();
        doctors.forEach(d -> d.setPassword(null));

        List<Appointment> appointments = appointmentRepository.findAll();
        long pending = appointments.stream().filter(a -> a.getStatus() == Appointment.AppointmentStatus.PENDING).count();
        long approved = appointments.stream().filter(a -> a.getStatus() == Appointment.AppointmentStatus.APPROVED).count();
        long rejected = appointments.stream().filter(a -> a.getStatus() == Appointment.AppointmentStatus.REJECTED).count();

        // Doctor stats - patients handled per doctor
        List<Map<String, Object>> doctorStats = new ArrayList<>();
        for (Doctor doctor : doctors) {
            Map<String, Object> stat = new HashMap<>();
            stat.put("doctor", doctor);
            long patientCount = appointmentRepository.findByDoctorIdOrderByAppointmentDateAsc(doctor.getId())
                    .stream().map(a -> a.getPatient().getId()).distinct().count();
            long apptCount = appointmentRepository.countByDoctorId(doctor.getId());
            stat.put("patientsHandled", patientCount);
            stat.put("totalAppointments", apptCount);
            doctorStats.add(stat);
        }

        dashboard.put("totalDoctors", totalDoctors);
        dashboard.put("totalPatients", totalPatients);
        dashboard.put("totalAppointments", totalAppointments);
        dashboard.put("pendingAppointments", pending);
        dashboard.put("approvedAppointments", approved);
        dashboard.put("rejectedAppointments", rejected);
        dashboard.put("doctors", doctors);
        dashboard.put("doctorStats", doctorStats);

        return ResponseEntity.ok(dashboard);
    }

    // Add doctor
    @PostMapping("/doctor/add")
    public ResponseEntity<Map<String, Object>> addDoctor(@RequestBody Doctor doctor) {
        Map<String, Object> response = new HashMap<>();
        if (doctorRepository.existsByEmail(doctor.getEmail())) {
            response.put(RESPONSE_SUCCESS, false);
            response.put(RESPONSE_MESSAGE, "Email already exists");
            return ResponseEntity.badRequest().body(response);
        }
        Doctor saved = doctorRepository.save(doctor);
        saved.setPassword(null);
        response.put(RESPONSE_SUCCESS, true);
        response.put("doctor", saved);
        return ResponseEntity.ok(response);
    }

    // Delete doctor
    @DeleteMapping("/doctor/{id}")
    public ResponseEntity<Map<String, Object>> deleteDoctor(@PathVariable Long id) {
        Map<String, Object> response = new HashMap<>();
        doctorRepository.deleteById(id);
        response.put(RESPONSE_SUCCESS, true);
        response.put(RESPONSE_MESSAGE, "Doctor deleted");
        return ResponseEntity.ok(response);
    }

    // Get all patients
    @GetMapping("/patients")
    public ResponseEntity<List<Patient>> getAllPatients() {
        List<Patient> patients = patientRepository.findAll();
        patients.forEach(p -> p.setPassword(null));
        return ResponseEntity.ok(patients);
    }
}
