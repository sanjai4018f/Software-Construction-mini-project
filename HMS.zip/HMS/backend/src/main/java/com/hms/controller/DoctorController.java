package com.hms.controller;

import com.hms.model.Doctor;
import com.hms.repository.DoctorRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.*;

@RestController
@RequestMapping("/api/doctor")
public class DoctorController {

    private static final String RESPONSE_SUCCESS = "success";
    private static final String RESPONSE_MESSAGE = "message";
    
    private final DoctorRepository doctorRepository;

    public DoctorController(DoctorRepository doctorRepository) {
        this.doctorRepository = doctorRepository;
    }

    // Login doctor
    @PostMapping("/login")
    public ResponseEntity<Map<String, Object>> login(@RequestBody Map<String, String> credentials) {
        Map<String, Object> response = new HashMap<>();
        String email = credentials.get("email");
        String password = credentials.get("password");

        Optional<Doctor> doctorOpt = doctorRepository.findByEmail(email);
        if (doctorOpt.isEmpty() || !doctorOpt.get().getPassword().equals(password)) {
            response.put(RESPONSE_SUCCESS, false);
            response.put(RESPONSE_MESSAGE, "Invalid email or password");
            return ResponseEntity.badRequest().body(response);
        }

        Doctor doctor = doctorOpt.get();
        doctor.setPassword(null);
        response.put(RESPONSE_SUCCESS, true);
        response.put(RESPONSE_MESSAGE, "Login successful");
        response.put("doctor", doctor);
        return ResponseEntity.ok(response);
    }

    // Get all doctors (for booking)
    @GetMapping("/all")
    public ResponseEntity<List<Doctor>> getAllDoctors() {
        List<Doctor> doctors = doctorRepository.findAll();
        doctors.forEach(d -> d.setPassword(null));
        return ResponseEntity.ok(doctors);
    }

    // Get doctor by ID
    @GetMapping("/{id}")
    public ResponseEntity<Doctor> getDoctorById(@PathVariable Long id) {
        return doctorRepository.findById(id)
                .map(d -> { d.setPassword(null); return ResponseEntity.ok(d); })
                .orElse(ResponseEntity.notFound().build());
    }
}
