package com.hms.repository;

import com.hms.model.Appointment;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import java.util.List;

public interface AppointmentRepository extends JpaRepository<Appointment, Long> {
    List<Appointment> findByPatientIdOrderByCreatedAtDesc(Long patientId);
    List<Appointment> findByDoctorIdOrderByAppointmentDateAsc(Long doctorId);
    long countByPatientId(Long patientId);
    long countByDoctorId(Long doctorId);

    @Query("SELECT a.doctor.id, COUNT(DISTINCT a.patient.id) FROM Appointment a GROUP BY a.doctor.id")
    List<Object[]> countDistinctPatientsByDoctor();
}
