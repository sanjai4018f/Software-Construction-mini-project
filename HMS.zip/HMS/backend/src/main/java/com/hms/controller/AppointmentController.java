package com.hms.controller;

import com.hms.model.Appointment;
import com.hms.model.Doctor;
import com.hms.model.Patient;
import com.hms.repository.AppointmentRepository;
import com.hms.repository.DoctorRepository;
import com.hms.repository.PatientRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.*;

@RestController
@RequestMapping("/api/appointment")
public class AppointmentController {

    private static final String RESPONSE_SUCCESS = "success";
    private static final String RESPONSE_MESSAGE = "message";
    
    private final AppointmentRepository appointmentRepository;
    private final PatientRepository patientRepository;
    private final DoctorRepository doctorRepository;

    public AppointmentController(AppointmentRepository appointmentRepository, 
                                 PatientRepository patientRepository, 
                                 DoctorRepository doctorRepository) {
        this.appointmentRepository = appointmentRepository;
        this.patientRepository = patientRepository;
        this.doctorRepository = doctorRepository;
    }

    // Book appointment
    @PostMapping("/book")
    public ResponseEntity<Map<String, Object>> bookAppointment(@RequestBody Map<String, Object> request) {
        Map<String, Object> response = new HashMap<>();
        try {
            Long patientId = Long.parseLong(request.get("patientId").toString());
            Long doctorId = Long.parseLong(request.get("doctorId").toString());
            String dateStr = request.get("appointmentDate").toString();
            String time = request.getOrDefault("appointmentTime", "10:00 AM").toString();
            String reason = request.getOrDefault("reason", "").toString();

            Patient patient = patientRepository.findById(patientId)
                    .orElseThrow(() -> new RuntimeException("Patient not found"));
            Doctor doctor = doctorRepository.findById(doctorId)
                    .orElseThrow(() -> new RuntimeException("Doctor not found"));

            Appointment appointment = new Appointment();
            appointment.setPatient(patient);
            appointment.setDoctor(doctor);
            appointment.setAppointmentDate(LocalDate.parse(dateStr));
            appointment.setAppointmentTime(time);
            appointment.setReason(reason);
            appointment.setStatus(Appointment.AppointmentStatus.PENDING);

            Appointment saved = appointmentRepository.save(appointment);
            response.put(RESPONSE_SUCCESS, true);
            response.put(RESPONSE_MESSAGE, "Appointment booked successfully");
            response.put("appointment", saved);
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            response.put(RESPONSE_SUCCESS, false);
            response.put(RESPONSE_MESSAGE, "Error: " + e.getMessage());
            return ResponseEntity.badRequest().body(response);
        }
    }

    // Get appointments by patient
    @GetMapping("/patient/{patientId}")
    public ResponseEntity<List<Appointment>> getPatientAppointments(@PathVariable Long patientId) {
        return ResponseEntity.ok(appointmentRepository.findByPatientIdOrderByCreatedAtDesc(patientId));
    }

    // Get appointments by doctor
    @GetMapping("/doctor/{doctorId}")
    public ResponseEntity<List<Appointment>> getDoctorAppointments(@PathVariable Long doctorId) {
        return ResponseEntity.ok(appointmentRepository.findByDoctorIdOrderByAppointmentDateAsc(doctorId));
    }

    // Update appointment status (approve/reject)
    @PutMapping("/{id}/status")
    public ResponseEntity<Map<String, Object>> updateStatus(
            @PathVariable Long id,
            @RequestBody Map<String, String> request) {
        Map<String, Object> response = new HashMap<>();
        Optional<Appointment> appointmentOpt = appointmentRepository.findById(id);

        if (appointmentOpt.isEmpty()) {
            response.put("success", false);
            response.put("message", "Appointment not found");
            return ResponseEntity.notFound().build();
        }

        Appointment appointment = appointmentOpt.get();
        String status = request.get("status");
        String notes = request.getOrDefault("notes", "");

        appointment.setStatus(Appointment.AppointmentStatus.valueOf(status));
        appointment.setNotes(notes);
        appointmentRepository.save(appointment);

        response.put("success", true);
        response.put("message", "Appointment " + status.toLowerCase());
        return ResponseEntity.ok(response);
    }

    // Get all appointments (admin)
    @GetMapping("/all")
    public ResponseEntity<List<Appointment>> getAllAppointments() {
        return ResponseEntity.ok(appointmentRepository.findAll());
    }
}
